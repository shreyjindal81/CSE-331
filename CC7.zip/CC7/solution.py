"""
Your name here
Coding Challenge 7
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from __future__ import annotations  # allow self-reference
from typing import List, Optional


class TreeNode:
    """
    Tree Node that contains a value as well as left and right pointers
    """
    def __init__(self, val: int, left: TreeNode = None, right: TreeNode = None):
        self.val = val
        self.left = left
        self.right = right


def rewind_combo(points: List[int]) -> List[Optional[int]]:
    """
    creates a list of largest smaller element to the left
    :param: integer list that needs to be modified
    :returns: the new list
    """
    result = []
    for i, val in enumerate(points):
        max_val = -1
        for j in range(i):
            if points[j] <= max_val or val <= points[j]:
                continue
            max_val = points[j]
        if max_val == -1:
            result.append(None)
        else:
            result.append(max_val)
    return result
